import { motion } from "motion/react";

export default function About() {
  return (
    <section id="about" className="py-24 bg-zinc-950 relative overflow-hidden">
      {/* Decorative background text */}
      <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center pointer-events-none opacity-[0.02]">
        <span className="text-[20vw] font-serif font-bold whitespace-nowrap">ESTABLISHED 1995</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=1000&auto=format&fit=crop"
                alt="Fashion Craftsmanship"
                className="w-full h-[600px] object-cover rounded-none"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-8 -right-8 bg-gold p-8 hidden md:block">
                <p className="text-black font-serif text-2xl italic">"Style is a way to say who you are without having to speak."</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col justify-center"
          >
            <h2 className="text-gold uppercase tracking-[0.2em] text-sm mb-4">About Us</h2>
            <h3 className="text-4xl md:text-5xl font-serif mb-8 leading-tight">Fashion with a Purpose.</h3>
            <div className="space-y-6 text-white/70 font-light leading-relaxed text-lg">
              <p>
                At <span className="text-gold font-medium">M.ASLAMFABRICS</span>, we believe that what you wear should reflect who you are—and what you care about.
              </p>
              <p>
                Every piece in our collection is designed with quality at its heart. From sourcing the finest materials to ensuring fair wages for our artisans, we are committed to making a positive impact on the industry.
              </p>
              <p>
                Our journey began with a simple vision: to bring timeless elegance to every woman's wardrobe. Today, we stand as a symbol of trust and excellence in the fabric industry, serving customers who appreciate the finer details of fashion.
              </p>
            </div>
            
            <div className="mt-12 grid grid-cols-2 gap-8 border-t border-white/10 pt-8">
              <div>
                <h4 className="text-gold text-3xl font-serif mb-2">25+</h4>
                <p className="text-sm uppercase tracking-widest text-white/50">Years Experience</p>
              </div>
              <div>
                <h4 className="text-gold text-3xl font-serif mb-2">10k+</h4>
                <p className="text-sm uppercase tracking-widest text-white/50">Happy Clients</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
