import { motion } from "motion/react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const services = [
  {
    title: "Unstitched Collection",
    description: "Premium quality unstitched fabrics in a variety of textures and prints.",
    image: "https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?q=80&w=800&auto=format&fit=crop",
    tag: "Versatile"
  },
  {
    title: "Designer Wear",
    description: "Exquisite designer pieces crafted with intricate details and modern cuts.",
    image: "https://images.unsplash.com/photo-1539109132381-31a1c97dee09?q=80&w=800&auto=format&fit=crop",
    tag: "Exclusive"
  },
  {
    title: "Female Variety",
    description: "A wide range of clothing options tailored specifically for the modern woman.",
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&auto=format&fit=crop",
    tag: "Trending"
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gold uppercase tracking-[0.2em] text-sm mb-4">Our Expertise</h2>
          <h3 className="text-4xl md:text-5xl font-serif">Curated Collections</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
            >
              <Card className="bg-zinc-900/50 border-white/5 overflow-hidden group hover:border-gold/30 transition-all duration-500 rounded-none">
                <div className="relative h-80 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-500"></div>
                  <Badge className="absolute top-4 right-4 bg-gold text-black rounded-none uppercase tracking-widest text-[10px]">
                    {service.tag}
                  </Badge>
                </div>
                <CardContent className="p-8">
                  <h4 className="text-2xl font-serif mb-4 group-hover:text-gold transition-colors">
                    {service.title}
                  </h4>
                  <p className="text-white/60 font-light leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
