import { motion } from "motion/react";

const images = [
  {
    url: "https://images.unsplash.com/photo-1581044777550-4cfa60707c03?q=80&w=800&auto=format&fit=crop",
    title: "Designer Collection",
    category: "Stitched"
  },
  {
    url: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?q=80&w=800&auto=format&fit=crop",
    title: "Floral Patterns",
    category: "Unstitched"
  },
  {
    url: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?q=80&w=800&auto=format&fit=crop",
    title: "Bridal Wear",
    category: "Designer"
  },
  {
    url: "https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?q=80&w=800&auto=format&fit=crop",
    title: "Summer Breeze",
    category: "Lawn"
  },
  {
    url: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop",
    title: "Winter Velvet",
    category: "Premium"
  },
  {
    url: "https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?q=80&w=800&auto=format&fit=crop",
    title: "Evening Glamour",
    category: "Party Wear"
  }
];

export default function Gallery() {
  return (
    <section id="gallery" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-gold uppercase tracking-[0.2em] text-sm mb-4">Visual Journey</h2>
            <h3 className="text-4xl md:text-5xl font-serif">Exquisite Gallery</h3>
          </div>
          <p className="text-white/50 max-w-sm font-light">
            A glimpse into our world of high-fashion fabrics and designer masterpieces.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group aspect-[3/4] overflow-hidden"
            >
              <img
                src={image.url}
                alt={image.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                <span className="text-gold text-xs uppercase tracking-widest mb-2">{image.category}</span>
                <h4 className="text-2xl font-serif text-white">{image.title}</h4>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
