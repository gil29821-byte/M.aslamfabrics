export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-black border-t border-white/10 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-serif tracking-widest text-gold font-bold mb-2">
              M.ASLAMFABRICS
            </h2>
            <p className="text-white/40 text-sm uppercase tracking-widest">
              Quality Fabrics • Timeless Style
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-8 text-sm uppercase tracking-widest text-white/60">
            <a href="#home" className="hover:text-gold transition-colors">Home</a>
            <a href="#services" className="hover:text-gold transition-colors">Services</a>
            <a href="#about" className="hover:text-gold transition-colors">About</a>
            <a href="#gallery" className="hover:text-gold transition-colors">Gallery</a>
            <a href="#contact" className="hover:text-gold transition-colors">Contact</a>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-white/40 text-xs uppercase tracking-widest">
              &copy; {currentYear} M.ASLAMFABRICS. All Rights Reserved.
            </p>
            <p className="text-white/20 text-[10px] mt-1 uppercase tracking-widest">
              Designed for Excellence
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
