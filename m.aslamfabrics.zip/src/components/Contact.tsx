import { motion } from "motion/react";
import { Phone, MapPin, Mail, MessageCircle, Instagram, Facebook } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Contact() {
  const contactInfo = [
    {
      icon: <MessageCircle className="w-6 h-6 text-gold" />,
      title: "WhatsApp",
      value: "+92 336 5605601",
      link: "https://wa.me/923365605601"
    },
    {
      icon: <MapPin className="w-6 h-6 text-gold" />,
      title: "Location",
      value: "Mini Plaza Kamra",
      link: "#"
    },
    {
      icon: <Mail className="w-6 h-6 text-gold" />,
      title: "Email",
      value: "info@maslamfabrics.com",
      link: "mailto:info@maslamfabrics.com"
    }
  ];

  return (
    <section id="contact" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-gold uppercase tracking-[0.2em] text-sm mb-4">Get In Touch</h2>
            <h3 className="text-4xl md:text-5xl font-serif mb-8">Visit Our Boutique</h3>
            <p className="text-white/60 mb-12 font-light leading-relaxed max-w-md">
              Whether you're looking for the perfect unstitched fabric or a custom designer piece, 
              our team is here to help you find exactly what you need.
            </p>

            <div className="space-y-8">
              {contactInfo.map((info, index) => (
                <a 
                  key={index}
                  href={info.link}
                  className="flex items-start gap-6 group"
                  target={info.link.startsWith('http') ? "_blank" : "_self"}
                  rel="noopener noreferrer"
                >
                  <div className="w-12 h-12 rounded-none border border-white/10 flex items-center justify-center group-hover:border-gold transition-colors">
                    {info.icon}
                  </div>
                  <div>
                    <h4 className="text-sm uppercase tracking-widest text-white/40 mb-1">{info.title}</h4>
                    <p className="text-xl font-serif group-hover:text-gold transition-colors">{info.value}</p>
                  </div>
                </a>
              ))}
            </div>

            <div className="mt-12 flex space-x-6">
              <a href="https://facebook.com" target="_blank" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-gold hover:text-black transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="https://instagram.com" target="_blank" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-gold hover:text-black transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://tiktok.com" target="_blank" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-gold hover:text-black transition-all">
                <span className="font-bold text-xs">TikTok</span>
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="bg-zinc-900 p-8 md:p-12 border border-white/5"
          >
            <h4 className="text-2xl font-serif mb-8 text-center">Inquiry Form</h4>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Full Name</label>
                  <input type="text" className="w-full bg-black border border-white/10 p-4 focus:border-gold outline-none transition-colors" placeholder="Your Name" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Phone Number</label>
                  <input type="text" className="w-full bg-black border border-white/10 p-4 focus:border-gold outline-none transition-colors" placeholder="+92 ..." />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-white/40">Message</label>
                <textarea rows={4} className="w-full bg-black border border-white/10 p-4 focus:border-gold outline-none transition-colors" placeholder="How can we help you?"></textarea>
              </div>
              <Button className="w-full bg-gold hover:bg-gold-dark text-black font-bold py-8 rounded-none uppercase tracking-widest">
                Send Message
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
